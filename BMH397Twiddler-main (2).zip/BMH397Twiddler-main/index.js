
// $(document).ready(() => {
//   const $body = $('body');
//   $body.html('');

//   const $tweets = streams.home.map((tweet) => {
//     const $tweet = $('<div></div>');
//     const text = `@${tweet.user}: ${tweet.message}`;

//     $tweet.text(text);

//     return $tweet;
//   });
//   $body.append($tweets);

// });

 
// $(document).ready(() => {
//   const $body = $('body');
//   $body.html('');

//   const $tweets = streams.home.map((tweet) => {
//     const $tweet = $('<div></div>');
//     const text = `@${tweet.user}: ${tweet.message}`;

//     $tweet.text(text);

//     return $tweet;
//   });
//   $body.append($tweets);

// });
// 
//  
$(document).ready(() => {
  //Global variables
  const $feed = $('#feed');
  const $tweetForm = $('form.tweet-form');
  const $usernameInput = $('#username-input'); //Selects the username input field
  const $tweetInput = $('#tweet-input'); //Selects the tweet input field
  const $refreshButton = $('#refresh-button'); //Selects the refresh button
  let lastTweetIndex = 0;

  //Lets make sure streams.home exists before proceeding
  if (!streams.home) {
    streams.home = []; // Initialize the home stream if it doesn't exist
  }

  //Now lets make a function to format the timestamps
  const formatTime = (timestamp) => {
    return moment(timestamp).fromNow();
  };

  //Now lets make a function to render tweets
  const renderTweets = () => {
    // Clear the feed
    $feed.empty();

    //Now loop through all tweets in reverse order
    for (let i = streams.home.length - 1; i >= 0; i--) {
      const tweet = streams.home[i];

      //Make sure the tweet message is a string and not empty
      const message = tweet.message && typeof tweet.message === 'string' ? tweet.message : '[Invalid message]';

      const $tweet = $('<div></div>').addClass('tweet-box');
      const $user = $('<div></div>').addClass('username').text(`@${tweet.user}`);
      const $message = $('<p></p>').text(message); //Render the message as a string
      const $time = $('<span></span>').addClass('timestamp').text(formatTime(tweet.created_at));

      //Now heres event to filter tweets by user
      $user.click(() => showUserTweets(tweet.user));

      //Now append details to the tweet-box div
      $tweet.append($user, $message, $time);
      $feed.append($tweet);
    }
  };

  //Lets make a function to check for new tweets and update the feed
  const checkForNewTweets = () => {
    //Instead of rendering only new tweets, we now render all tweets in streams.home
    renderTweets();
  };

  //Function to display tweets from a specific user
  const showUserTweets = (user) => {
    const userTweets = streams.users[user] || [];
    renderTweets(userTweets);
  };

  //Function to filter tweets by a specific hashtag
  const filterTweetsByHashtag = (hashtag) => {
    const filteredTweets = streams.home.filter((tweet) => {
      //Now check if tweet.message is a valid string before using .includes()
      return typeof tweet.message === 'string' && tweet.message.includes(hashtag);
    });
    renderTweets(filteredTweets);
  };

  //Yay event listener for hashtag clicks
  $('.hashtag').click(function () {
    const hashtag = $(this).text();
    filterTweetsByHashtag(hashtag);
  });

  //Function to add the tweet to the streams database
  const writeTweet = (tweet) => {
    //Lets make sure the streams object is initialized
    if (!streams.home) {
      streams.home = [];
    }

    //Check if the user exists in the streams.users
    if (!streams.users[tweet.user]) {
      streams.users[tweet.user] = [];
    }

    //Then add the tweet to the home timeline
    streams.home.push(tweet);

    //Then add the tweet to the user's timeline
    streams.users[tweet.user].push(tweet);

    //Please work 
    console.log('Updated streams:', streams);
  };

  //Now lets make a function to set up the tweet form and handle submission
  const setupTweetForm = () => {
    const $form = $('form.tweet-form');

    //Handle form submission for a new tweet
    $form.submit((event) => {
      event.preventDefault();
      let message = $tweetInput.val().trim(); // Trim the message to remove leading/trailing whitespace
      const username = $usernameInput.val().trim() || 'Anonymous'; // Get the username or default to "Anonymous"

      console.log(`Attempting to submit tweet: username: ${username}, message: ${message}`);

      //Make sure message is valid and not an object
      if (!message || typeof message !== 'string' || message === '') {
        console.error('Invalid message:', message);
        return;
      }

      //Set the global visitor property before writing the tweet
      window.visitor = username; // This sets the global `visitor` property

      //And check if the user exists in streams.users
      if (!streams.users[username]) {
        streams.users[username] = []; // Initialize the user in streams.users if they don't exist
        console.log(`Creating new user: ${username}`);
      }

      //Log the newTweet structure before writing
      const newTweet = { user: username, message: message, created_at: new Date() };
      console.log('New Tweet:', newTweet);

      //Check if the writeTweet function is properly called
      try {
        console.log('Writing tweet...');
        writeTweet(newTweet); // Call the writeTweet function with the validated tweet

        console.log('Tweet successfully written!');

        //Show the tweet for at least 3 seconds before updating the feed
        setTimeout(() => {
          checkForNewTweets(); // Update the feed with the new tweet after 3 seconds
        }, 3000); // 3000 ms = 3 seconds

        $tweetInput.val(''); // Clear the input field
        $usernameInput.val(''); // Clear the username field
      } catch (error) {
        console.error('Error writing tweet:', error);
      }
    });
  };

  //Refresh button click event to refresh tweets
  $refreshButton.click(() => {
    checkForNewTweets();
  });

  //Initialize the form and tweet fetching
  const init = () => {
    setupTweetForm();
    checkForNewTweets();
    setInterval(checkForNewTweets, 5000); // Check for new tweets every 5 seconds (slowed down)
  };

  //Run the initialization :'D
  init();
});

